#!/bin/bash
sudo ./scripts/fixMakeFiles.sh
sudo ./scripts/makeKernel.sh

