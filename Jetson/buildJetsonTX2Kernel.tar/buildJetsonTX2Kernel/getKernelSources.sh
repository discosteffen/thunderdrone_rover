#!/bin/bash
# Install the kernel source for L4T
sudo ./scripts/getKernelSources.sh
