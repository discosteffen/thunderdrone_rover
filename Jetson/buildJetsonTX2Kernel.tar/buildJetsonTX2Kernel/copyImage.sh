#!/bin/bash
sudo ./scripts/copyImage.sh
